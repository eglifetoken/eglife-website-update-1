// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title EGLIFE Token (Reference Template)
 * @notice This is a standalone, flattened ERC20 implementation with Ownable, Pausable,
 *         and a simple transfer tax sent to a designated tax wallet.
 * @dev    This file is provided for transparency in the public GitHub repo.
 *         It may NOT match the deployed bytecode at 0xca326a5e15b9451efC1A6BddaD6fB098a4D09113.
 *         Do NOT use this for verification unless it is your actual compiled source.
 */

// -------------------- Context --------------------
abstract contract Context {
    function _msgSender() internal view virtual returns (address) {
        return msg.sender;
    }
    function _msgData() internal view virtual returns (bytes calldata) {
        return msg.data;
    }
}

// -------------------- Ownable --------------------
abstract contract Ownable is Context {
    address private _owner;

    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);

    constructor() {
        _transferOwnership(_msgSender());
    }

    modifier onlyOwner() {
        require(owner() == _msgSender(), "Ownable: caller is not the owner");
        _;
    }

    function owner() public view virtual returns (address) {
        return _owner;
    }

    function transferOwnership(address newOwner) public virtual onlyOwner {
        require(newOwner != address(0), "Ownable: new owner is the zero address");
        _transferOwnership(newOwner);
    }

    function _transferOwnership(address newOwner) internal virtual {
        address oldOwner = _owner;
        _owner = newOwner;
        emit OwnershipTransferred(oldOwner, newOwner);
    }
}

// -------------------- Pausable --------------------
abstract contract Pausable is Context {
    event Paused(address account);
    event Unpaused(address account);

    bool private _paused;

    constructor() {
        _paused = false;
    }

    function paused() public view virtual returns (bool) {
        return _paused;
    }

    modifier whenNotPaused() {
        require(!paused(), "Pausable: paused");
        _;
    }

    modifier whenPaused() {
        require(paused(), "Pausable: not paused");
        _;
    }

    function _pause() internal virtual whenNotPaused {
        _paused = true;
        emit Paused(_msgSender());
    }

    function _unpause() internal virtual whenPaused {
        _paused = false;
        emit Unpaused(_msgSender());
    }
}

// -------------------- IERC20 --------------------
interface IERC20 {
    function totalSupply() external view returns (uint256);
    function balanceOf(address account) external view returns (uint256);
    function transfer(address to, uint256 value) external returns (bool);
    function allowance(address owner, address spender) external view returns (uint256);
    function approve(address spender, uint256 value) external returns (bool);
    function transferFrom(address from, address to, uint256 value) external returns (bool);

    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);
}

// -------------------- IERC20Metadata --------------------
interface IERC20Metadata is IERC20 {
    function name() external view returns (string memory);
    function symbol() external view returns (string memory);
    function decimals() external view returns (uint8);
}

// -------------------- ERC20 base --------------------
contract ERC20 is Context, IERC20, IERC20Metadata {
    mapping(address => uint256) private _balances;
    mapping(address => mapping(address => uint256)) private _allowances;
    uint256 private _totalSupply;

    string private _name;
    string private _symbol;

    constructor(string memory name_, string memory symbol_) {
        _name = name_;
        _symbol = symbol_;
    }

    function name() public view virtual override returns (string memory) {
        return _name;
    }

    function symbol() public view virtual override returns (string memory) {
        return _symbol;
    }

    function decimals() public view virtual override returns (uint8) {
        return 18;
    }

    function totalSupply() public view virtual override returns (uint256) {
        return _totalSupply;
    }

    function balanceOf(address account) public view virtual override returns (uint256) {
        return _balances[account];
    }

    function transfer(address to, uint256 value) public virtual override returns (bool) {
        address owner = _msgSender();
        _transfer(owner, to, value);
        return true;
    }

    function allowance(address owner, address spender) public view virtual override returns (uint256) {
        return _allowances[owner][spender];
    }

    function approve(address spender, uint256 value) public virtual override returns (bool) {
        address owner = _msgSender();
        _approve(owner, spender, value);
        return true;
    }

    function transferFrom(address from, address to, uint256 value) public virtual override returns (bool) {
        address spender = _msgSender();
        _spendAllowance(from, spender, value);
        _transfer(from, to, value);
        return true;
    }

    function increaseAllowance(address spender, uint256 addedValue) public virtual returns (bool) {
        _approve(_msgSender(), spender, _allowances[_msgSender()][spender] + addedValue);
        return true;
    }

    function decreaseAllowance(address spender, uint256 subtractedValue) public virtual returns (bool) {
        uint256 currentAllowance = _allowances[_msgSender()][spender];
        require(currentAllowance >= subtractedValue, "ERC20: decreased allowance below zero");
        unchecked {
            _approve(_msgSender(), spender, currentAllowance - subtractedValue);
        }
        return true;
    }

    function _transfer(address from, address to, uint256 value) internal virtual {
        require(from != address(0), "ERC20: transfer from the zero address");
        require(to != address(0), "ERC20: transfer to the zero address");

        uint256 fromBalance = _balances[from];
        require(fromBalance >= value, "ERC20: transfer amount exceeds balance");
        unchecked {
            _balances[from] = fromBalance - value;
        }
        _balances[to] += value;

        emit Transfer(from, to, value);
    }

    function _mint(address account, uint256 value) internal virtual {
        require(account != address(0), "ERC20: mint to the zero address");
        _totalSupply += value;
        _balances[account] += value;
        emit Transfer(address(0), account, value);
    }

    function _burn(address account, uint256 value) internal virtual {
        require(account != address(0), "ERC20: burn from the zero address");
        uint256 accountBalance = _balances[account];
        require(accountBalance >= value, "ERC20: burn amount exceeds balance");
        unchecked {
            _balances[account] = accountBalance - value;
        }
        _totalSupply -= value;
        emit Transfer(account, address(0), value);
    }

    function _approve(address owner, address spender, uint256 value) internal virtual {
        require(owner != address(0), "ERC20: approve from the zero address");
        require(spender != address(0), "ERC20: approve to the zero address");
        _allowances[owner][spender] = value;
        emit Approval(owner, spender, value);
    }

    function _spendAllowance(address owner, address spender, uint256 value) internal virtual {
        uint256 currentAllowance = allowance(owner, spender);
        if (currentAllowance != type(uint256).max) {
            require(currentAllowance >= value, "ERC20: insufficient allowance");
            unchecked {
                _approve(owner, spender, currentAllowance - value);
            }
        }
    }
}

// -------------------- EGLIFE (reference) --------------------
contract EGLIFE is ERC20, Ownable, Pausable {
    // transfer tax in basis points (1% = 100), capped by MAX_TAX_BPS
    uint16 public taxBps;
    uint16 public constant MAX_TAX_BPS = 500; // 5% cap
    address public taxWallet;

    event TaxWalletUpdated(address indexed oldWallet, address indexed newWallet);
    event TaxBpsUpdated(uint16 oldBps, uint16 newBps);

    constructor(
        string memory name_,
        string memory symbol_,
        uint256 initialSupply_,
        address taxWallet_,
        uint16 taxBps_
    ) ERC20(name_, symbol_) {
        require(taxWallet_ != address(0), "Tax wallet zero");
        require(taxBps_ <= MAX_TAX_BPS, "Tax too high");
        taxWallet = taxWallet_;
        taxBps = taxBps_;
        _mint(_msgSender(), initialSupply_);
    }

    // Owner controls
    function pause() external onlyOwner { _pause(); }
    function unpause() external onlyOwner { _unpause(); }

    function setTaxWallet(address newWallet) external onlyOwner {
        require(newWallet != address(0), "Tax wallet zero");
        emit TaxWalletUpdated(taxWallet, newWallet);
        taxWallet = newWallet;
    }

    function setTaxBps(uint16 newBps) external onlyOwner {
        require(newBps <= MAX_TAX_BPS, "Tax too high");
        emit TaxBpsUpdated(taxBps, newBps);
        taxBps = newBps;
    }

    // Overrides
    function _transfer(address from, address to, uint256 value) internal override whenNotPaused {
        if (taxBps == 0 || taxWallet == address(0) || from == taxWallet || to == taxWallet) {
            // No tax if tax disabled or interacting with the tax wallet
            super._transfer(from, to, value);
        } else {
            uint256 tax = (value * uint256(taxBps)) / 10000;
            uint256 net = value - tax;
            if (tax > 0) {
                super._transfer(from, taxWallet, tax);
            }
            super._transfer(from, to, net);
        }
    }
}
