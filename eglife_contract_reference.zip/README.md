# EGLIFE.sol (Reference Template, Flattened)

**Important:** This is a **reference, flattened Solidity file** for public transparency on GitHub.  
It is **not** guaranteed to be bytecode-identical to the deployed contract at
`0xca326a5e15b9451efC1A6BddaD6fB098a4D09113` on BNB Smart Chain.

Use this file for **documentation** only.  
For on-chain verification, you must extract the exact verified source from your compiler/build or from the explorer and re‑flatten it.

- Solidity: ^0.8.20
- License: MIT
- Features included in this template:
  - ERC20 with decimals 18
  - Ownable (owner can update tax wallet and tax rate caps)
  - Pausable (owner can pause transfers)
  - Transfer tax (sent to tax wallet); max tax = 5% (configurable but capped)
  - Initial supply minted to deployer (can be edited before deployment if used)

> Prepared on 2025-08-28 15:34:40 UTC
